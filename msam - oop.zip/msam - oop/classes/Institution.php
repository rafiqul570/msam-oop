<?php
spl_autoload_register(function($class_name){
include "../../classes/".$class_name.".php";
}); 

//error_reporting(0);
$session = new Session();  

/*
class
*/ 

class Institution{

  private $db;

  public function __construct(){
    $this->db = new Database();
      
   }


//Insert DATA
 public function insertInstitution($data){
    $ins_name = $data['ins_name'];
            
    if ($ins_name == "" ) {
        
      $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                      <span aria-hidden='true'>&times;</span>
                  </button>
              </div>";
    
         return $msg; 
   
 } 

   
   $query = "INSERT INTO institution (ins_name) VALUES ('$ins_name');";
    
    $result = $this->db->insert($query);

   if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

        $msg = '<div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         <strong>Error !</strong> Data Not Inserted.
        </div>';
  
       return $msg; 
     }
 
    
    }
  
  public function getAllInstitutionData(){
        $query = "SELECT *FROM institution ORDER BY ins_id DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

//Select data in Update page (Admission)
 
    // public function getAdmissionById($id){
      
    // $sql = "SELECT * FROM institution WHERE id = '$id' LIMIT 1";
    //     $query = $this->db->select($sql);
    //             $result = mysqli_fetch_array($query);
    //             return $result;
    //  }


//Update Image/Data
//    public function updateAdmission($id, $data){
//       $sql = "SELECT * FROM institution WHERE id = '$id'";
//       $result = $this->db->select($sql);
//       $row = mysqli_fetch_array($result);
      
//       $name = $data['name'];
//       $fname = $data['fname'];
//       $phone1 = $data['phone1'];
//       $mname = $data['mname'];
//       $phone2 = $data['phone2'];
//       $p_village = $data['p_village'];
//       $p_post = $data['p_post'];
//       $p_upazila = $data['p_upazila'];
//       $p_district = $data['p_district'];
//       $c_village = $data['c_village'];
//       $c_post = $data['c_post'];
//       $c_upazila = $data['c_upazila'];
//       $c_district = $data['c_district'];
//       $b_date = $data['b_date'];
//       $bid = $data['bid'];
//       $f_occupation = $data['f_occupation'];
//       $f_nid = $data['f_nid'];
//       $m_occupation = $data['m_occupation'];
//       $m_nid = $data['m_nid'];
//       $admi_class = $data['admi_class'];
//       $admi_date = $data['admi_date'];
//       $last_ins_name = $data['last_ins_name'];
    
        
//       $img = $_FILES['image'];
//       $tmp_name = $img['tmp_name'];
//       $image = uniqid().$_FILES['image']['name'];
//       $fileName = '../uploads/image/'.$image;
//       if ($img['size'] > 1) {
//         if (file_exists("../uploads/image/".$row['image']) && !empty($row['image'])) {
//           unlink("../uploads/image/".$row['image']);
//         }

//       move_uploaded_file($tmp_name, $fileName);

// $query = "UPDATE admission SET name = '$name', fname = '$fname', phone1 = '$phone1',
//     mname = '$mname', phone2 = '$phone2', p_village = '$p_village', p_post = '$p_post', 
//     p_upazila = '$p_upazila', p_district = '$p_district', c_village = '$c_village',
//     c_post = '$c_post', c_upazila = '$c_upazila', c_district = '$c_district',
//     b_date = '$b_date', bid = '$bid', f_occupation = '$f_occupation', f_nid= '$f_nid',
//     m_occupation = '$m_occupation', m_nid = '$m_nid', admi_class = '$admi_class', 
//     admi_date = '$admi_date', last_ins_name = '$last_ins_name', image = '$image' 
//     WHERE id = '$id' ";
    
    
//     }else{
    

// $query = "UPDATE admission SET name = '$name', fname = '$fname', phone1 = '$phone1',
//     mname = '$mname', phone2 = '$phone2', p_village = '$p_village', p_post = '$p_post', 
//     p_upazila = '$p_upazila', p_district = '$p_district', c_village = '$c_village',
//     c_post = '$c_post', c_upazila = '$c_upazila', c_district = '$c_district',
//     b_date = '$b_date', bid = '$bid', f_occupation = '$f_occupation', f_nid= '$f_nid',
//     m_occupation = '$m_occupation', m_nid = '$m_nid', admi_class = '$admi_class', 
//     admi_date = '$admi_date', last_ins_name = '$last_ins_name' 
//     WHERE id = '$id' ";
    
//     }

//     $result = $this->db->update($query);

//     if ($result) {
//       header("Location: all-student.php?msg=");
   

//   }else{

//       header("Location: update.php?msg=".urlencode('Data Not Updated'));
  
//   }
   

//   } 


// //Delete Admission  
//   public function deleteAdmission($id){
        
//         $img = "SELECT * FROM institution WHERE id = '$id'";
//         $result = $this->db->select($img);
//             $row = mysqli_fetch_array($result);
//             $image = $row['image'];
//             if(!empty($image)){
//             unlink("../uploads/image/".$image); 
//             }
           
//             $query = "DELETE FROM institution WHERE id = '$id'";
//             $result = $this->db->delete($query);   
            
       
//         if ($result){
//           $msg = '<div class="alert alert-danger alert-dismissible">
//               <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
//                <strong>Success !</strong> Data Delete Successfully.
//               </div>';
      
//            return $msg; 
          
     
//     }else{

//       $msg = '<div class="alert alert-danger alert-dismissible">
//                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
//                  <strong>Error !</strong> Data Not Deleted.
//                 </div>';
        
//              return $msg; 
    
//     }
    
//         }


 }

 ?>